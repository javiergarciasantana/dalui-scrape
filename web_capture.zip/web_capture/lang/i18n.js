const dict = {
    es: {
        flag: "🇪🇸",
        tabActual: "Actual", tabBulk: "Bulk",
        popDesc1: "Extrae el producto de la pestaña en la que estás navegando ahora mismo.",
        popBtn1: "Extraer Producto", popBtnExtracting: "Extrayendo... ⏳",
        popDesc2: "Pega hasta 5 URLs (una por línea):",
        popBtn2: "Extraer Cola", popErrLimit: "Introduce entre 1 y 5 URLs",
        optTitle: "⚙️ Configuración de Reglas", optAddRule: "Añadir Nueva Regla",
        optDom: "Dominio (ej. daliubaze.lt)", optTitleSel: "Selector del Título",
        optPriceSel: "Selector del Precio", optImgSel: "Selector de Imágenes",
        optSkuSel: "Selector SKU (Kodas)", optDescSel: "Selector de Descripción / Specs (opcional)",
        optBtnSave: "Guardar Regla", optBtnCancel: "Cancelar Edición", optBtnUpdate: "Actualizar Regla",
        optActiveRules: "Reglas Activas", optNoRules: "No hay reglas configuradas aún.",
        optBtnEdit: "Editar", optBtnDel: "Borrar", msgSaved: "¡Regla guardada con éxito!",
        prevTitle: "✏️ Ajustar Producto antes de Publicar", prevBtnPub: "🚀 Publicar en WordPress",
        prevLblTitle: "Título del Producto", prevLblPrice: "Precio (€)",
        prevLblSku: "Kodas (SKU)", prevLblCat: "Categoría",
        prevLblImg: "🖼️ Ordenar Imágenes (Arrastra para reordenar, X para borrar)",
        prevLblDesc: "Descripción HTML (Especificaciones)", prevLiveTitle: "👁️ Vista Final en tu Plantilla (Tiempo Real)",
        prevBtnPrev: "⬅️ Anterior", prevBtnNext: "Siguiente ➡️", badgeMain: "1º (Principal)",
        wordProd: "Producto", wordOf: "de"
    },
    en: {
        flag: "🇬🇧",
        tabActual: "Current", tabBulk: "Bulk",
        popDesc1: "Extract the product from the tab you are currently browsing.",
        popBtn1: "Extract Product", popBtnExtracting: "Extracting... ⏳",
        popDesc2: "Paste up to 5 URLs (one per line):",
        popBtn2: "Extract Queue", popErrLimit: "Enter between 1 and 5 URLs",
        optTitle: "⚙️ Rule Configuration", optAddRule: "Add New Rule",
        optDom: "Domain (e.g. daliubaze.lt)", optTitleSel: "Title Selector",
        optPriceSel: "Price Selector", optImgSel: "Image Selector",
        optSkuSel: "SKU Selector (Kodas)", optDescSel: "Description / Specs Selector (optional)",
        optBtnSave: "Save Rule", optBtnCancel: "Cancel Edit", optBtnUpdate: "Update Rule",
        optActiveRules: "Active Rules", optNoRules: "No rules configured yet.",
        optBtnEdit: "Edit", optBtnDel: "Delete", msgSaved: "Rule saved successfully!",
        prevTitle: "✏️ Adjust Product before Publishing", prevBtnPub: "🚀 Publish to WordPress",
        prevLblTitle: "Product Title", prevLblPrice: "Price (€)",
        prevLblSku: "SKU (Kodas)", prevLblCat: "Category",
        prevLblImg: "🖼️ Order Images (Drag to reorder, X to delete)",
        prevLblDesc: "HTML Description (Specs)", prevLiveTitle: "👁️ Final View in Template (Real Time)",
        prevBtnPrev: "⬅️ Previous", prevBtnNext: "Next ➡️", badgeMain: "1st (Main)",
        wordProd: "Product", wordOf: "of"
    },
    lt: {
        flag: "🇱🇹",
        tabActual: "Dabartinis", tabBulk: "Masinis",
        popDesc1: "Ištraukite produktą iš skirtuko, kurį šiuo metu naršote.",
        popBtn1: "Ištraukti Produktą", popBtnExtracting: "Ištraukiama... ⏳",
        popDesc2: "Įklijuokite iki 5 URL (po vieną eilutėje):",
        popBtn2: "Ištraukti Eilę", popErrLimit: "Įveskite nuo 1 iki 5 URL",
        optTitle: "⚙️ Taisyklių Nustatymai", optAddRule: "Pridėti naują taisyklę",
        optDom: "Domenas (pvz., daliubaze.lt)", optTitleSel: "Pavadinimo parinkiklis",
        optPriceSel: "Kainos parinkiklis", optImgSel: "Nuotraukų parinkiklis",
        optSkuSel: "SKU parinkiklis (Kodas)", optDescSel: "Aprašymo / Specifikacijų parinkiklis (neprivaloma)",
        optBtnSave: "Išsaugoti Taisyklę", optBtnCancel: "Atšaukti", optBtnUpdate: "Atnaujinti Taisyklę",
        optActiveRules: "Aktyvios Taisyklės", optNoRules: "Dar nėra sukurtų taisyklių.",
        optBtnEdit: "Redaguoti", optBtnDel: "Ištrinti", msgSaved: "Taisyklė išsaugota sėkmingai!",
        prevTitle: "✏️ Koreguoti produktą prieš publikuojant", prevBtnPub: "🚀 Publikuoti į WordPress",
        prevLblTitle: "Produkto Pavadinimas", prevLblPrice: "Kaina (€)",
        prevLblSku: "Kodas (SKU)", prevLblCat: "Kategorija",
        prevLblImg: "🖼️ Rikiuoti nuotraukas (Vilkite norėdami perrikiuoti, X ištrinti)",
        prevLblDesc: "HTML Aprašymas (Specifikacijos)", prevLiveTitle: "👁️ Galutinis vaizdas šablone (Realiu laiku)",
        prevBtnPrev: "⬅️ Ankstesnis", prevBtnNext: "Kitas ➡️", badgeMain: "1-a (Pagrindinė)",
        wordProd: "Produktas", wordOf: "iš"
    }
};

const langs = ['es', 'en', 'lt'];
let currentLang = 'es';

async function initI18n() {
    return new Promise(resolve => {
        chrome.storage.local.get(['appLang'], (res) => {
            if (res.appLang && dict[res.appLang]) currentLang = res.appLang;
            applyI18nToDOM();
            resolve();
        });
    });
}

function toggleLang() {
    let nextIndex = (langs.indexOf(currentLang) + 1) % langs.length;
    currentLang = langs[nextIndex];
    chrome.storage.local.set({ appLang: currentLang });
    applyI18nToDOM();
}

function applyI18nToDOM() {
    document.querySelectorAll('[data-i18n]').forEach(el => {
        const key = el.getAttribute('data-i18n');
        if (dict[currentLang][key]) {
            if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
                el.placeholder = dict[currentLang][key];
            } else {
                el.innerText = dict[currentLang][key];
            }
        }
    });
    const flagBtn = document.getElementById('btnLang');
    if (flagBtn) flagBtn.innerText = dict[currentLang].flag;
}

function t(key) {
    return dict[currentLang][key] || key;
}